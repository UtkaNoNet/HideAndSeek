package com.hideandseek.listeners;

import com.hideandseek.GameManager;
import com.hideandseek.GameState;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

/**
 * Если игрок заходит на сервер, пока игра уже идёт, он НЕ становится
 * участником текущего раунда (список players в GameManager фиксируется
 * в момент /start) — он просто наблюдатель до следующей игры.
 * Это простая заглушка на будущее расширение (например, авто-присоединение к следующему раунду).
 */
public class JoinListener implements Listener {

    private final GameManager gameManager;

    public JoinListener(GameManager gameManager) {
        this.gameManager = gameManager;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (gameManager.getState() != GameState.IDLE) {
            event.getPlayer().sendMessage("Игра уже идёт, ты сможешь присоединиться к следующему раунду.");
        }
    }
}
