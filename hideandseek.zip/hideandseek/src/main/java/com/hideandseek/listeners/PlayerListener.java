package com.hideandseek.listeners;

import com.hideandseek.GameManager;
import com.hideandseek.GameState;
import com.hideandseek.model.GamePlayer;
import com.hideandseek.model.GameRole;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.Bukkit;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;

/**
 * Общие правила поведения во время игры, не связанные напрямую с уроном/выходом:
 *  - прячущиеся не теряют голод (чтобы не тратить время на еду);
 *  - подстраховка на случай реальной смерти (телепорт вместо экрана смерти).
 */
public class PlayerListener implements Listener {

    private final GameManager gameManager;

    public PlayerListener(GameManager gameManager) {
        this.gameManager = gameManager;
    }

    @EventHandler
    public void onFoodChange(FoodLevelChangeEvent event) {
        if (gameManager.getState() == GameState.IDLE) return;
        if (!(event.getEntity() instanceof Player player)) return;

        GamePlayer gp = gameManager.getPlayers().get(player.getUniqueId());
        if (gp != null && gp.getRole() != GameRole.NONE) {
            event.setCancelled(true); // голод не важен в мини-игре
        }
    }

    /**
     * На случай, если DamageListener не успел отменить урон (например, урон от лавы/пропасти)
     * и реальная смерть всё же случилась — обрабатываем как поимку/выход, а не даём respawn-экран.
     */
    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        GamePlayer gp = gameManager.getPlayers().get(player.getUniqueId());
        if (gp == null || gp.getRole() != GameRole.HIDER) return;

        event.setDeathMessage(null);
        event.getDrops().clear();
        event.setDroppedExp(0);
        gameManager.catchHider(player);

        // Принудительно респавним игрока через 1 тик, чтобы не завис экран смерти
        Bukkit.getScheduler().runTask(gameManager.getPluginInstance(), () -> {
            if (player.isOnline()) {
                player.spigot().respawn();
            }
        });
    }
}
