package com.hideandseek.listeners;

import com.hideandseek.GameManager;
import com.hideandseek.GameState;
import com.hideandseek.model.GamePlayer;
import com.hideandseek.model.GameRole;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

/**
 * У прячущегося всего 1 сердце (2 HP), поэтому практически любой урон
 * его бы "убил" по-настоящему. Вместо реальной смерти мы отменяем урон,
 * если он смертельный, и превращаем это в "поимку" (GameManager.catchHider).
 *
 * Так работает и урон от стрелы искателя, и случайный урон от кактуса/лавы —
 * что логично для мини-игры: прячущийся просто выбывает, а не респавнится.
 */
public class DamageListener implements Listener {

    private final GameManager gameManager;

    public DamageListener(GameManager gameManager) {
        this.gameManager = gameManager;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent event) {
        if (gameManager.getState() != GameState.SEARCHING) return;
        if (!(event.getEntity() instanceof Player player)) return;

        GamePlayer gp = gameManager.getPlayers().get(player.getUniqueId());
        if (gp == null || gp.getRole() != GameRole.HIDER || !gp.isAlive()) return;

        if (event.getFinalDamage() >= player.getHealth()) {
            event.setCancelled(true);
            gameManager.catchHider(player);
        }
    }
}
