package com.hideandseek.listeners;

import com.hideandseek.GameManager;
import com.hideandseek.GameState;
import com.hideandseek.managers.VoteManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

/**
 * Предметное голосование: игрок кликает ПКМ/ЛКМ по предмету карты в руке —
 * это и есть его голос. Реальный подсчёт/выбор победителя — в VoteManager.
 */
public class InventoryListener implements Listener {

    private final GameManager gameManager;

    public InventoryListener(GameManager gameManager) {
        this.gameManager = gameManager;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (gameManager.getState() != GameState.VOTING) return;

        ItemStack item = event.getItem();
        if (item == null) return;

        String mapId = VoteManager.mapIdForMaterial(item.getType());
        if (mapId == null) return;

        Player player = event.getPlayer();
        event.setCancelled(true); // не даём взаимодействовать с миром предметом голосования
        gameManager.getVoteManager().vote(player, mapId);
    }
}
